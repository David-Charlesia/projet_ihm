import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("e6689d8c-76e4-49a8-8995-186d91812ebb")
public class Cercle extends Figure {
    @objid ("0aeec5bb-171b-499d-83fe-cbdc0d89e798")
    private int rayon;

    @objid ("8471828d-b578-4513-9af9-a14d4f7305ac")
    int getRayon() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.rayon;
    }

    @objid ("c3b40241-e7b1-4bfc-9ac6-b72ee0e6a9ad")
    void setRayon(int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.rayon = value;
    }

}
