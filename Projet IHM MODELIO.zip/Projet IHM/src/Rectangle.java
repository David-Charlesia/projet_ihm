import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("77542866-bdd7-4bfa-86c2-b484455b1f37")
public class Rectangle extends Figure {
    @objid ("593bdc86-f12d-498e-abbe-67ee4af7fd16")
    private Point p1;

    @objid ("cae45f38-1657-45af-96ab-6ec26ece87ed")
    private Point p2;

    @objid ("5f66076d-45bb-4865-920c-3ceeeb74b44e")
    public Point point;

    @objid ("5f22c591-0488-4a10-9e28-f1bed41b0a68")
    Point getP1() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.p1;
    }

    @objid ("f25bd9c9-24a6-4dd1-b9bb-bd970bce1281")
    void setP1(Point value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.p1 = value;
    }

    @objid ("7771da21-a0ce-4d0b-8b11-0aa9c9911f3c")
    Point getP2() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.p2;
    }

    @objid ("3861d68a-f582-4903-800c-dde4ea3c16e3")
    void setP2(Point value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.p2 = value;
    }

}
