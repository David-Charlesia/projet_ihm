import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("80c75fd2-6540-43dc-a3e0-f8f59af20cb2")
public class Ellipse extends Cercle {
    @objid ("729223af-2aa6-4781-9f51-7075daa2ec8e")
    private int grand_rayon;

    @objid ("5991f1ec-361f-4fdc-ab11-02b83ccb8bca")
    int getGrand_rayon() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.grand_rayon;
    }

    @objid ("930bf047-a492-4772-aabf-7dd52a1946a3")
    void setGrand_rayon(int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.grand_rayon = value;
    }

}
