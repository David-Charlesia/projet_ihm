import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("febff7ec-ad61-4ebf-89aa-bf097263e80c")
public class Figure {
    @objid ("24a7d243-c6f9-4f48-855d-32b1411b1cb3")
    private int x;

    @objid ("6db644e1-0308-420a-a060-b08f3989efb2")
    private int y;

    @objid ("ff133ca9-9e6b-499e-afa3-7d1cba7c6af6")
    private double rotation;

    @objid ("8f4ae388-5676-42ce-9eec-2db93d65b085")
    int getX() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.x;
    }

    @objid ("890f6c91-f25a-4aba-9ec6-fb72ac41de3a")
    void setX(int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.x = value;
    }

    @objid ("2c95f8ce-7073-4cce-ad43-8bdff57f7549")
    int getY() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.y;
    }

    @objid ("bc523dbc-2378-427d-b5e7-cf9976a1b7b7")
    void setY(int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.y = value;
    }

    @objid ("6a345173-3176-4c59-9bf5-d3b202f4a8f2")
    double getRotation() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.rotation;
    }

    @objid ("a36b76c0-31f9-406e-ad7e-6f5390645d90")
    void setRotation(double value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.rotation = value;
    }

}
