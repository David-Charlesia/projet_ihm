import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("6c51749d-2051-41d8-a441-06e87c58264d")
public class Triangle extends Figure {
    @objid ("fffb15ae-e2c9-4fe9-a5cc-a728c06e56f9")
    private Point p1;

    @objid ("0b8164cb-af51-4988-98bc-f828afd79df8")
    public Point point;

    @objid ("df4f52da-3622-4922-a7bc-384d96583891")
    Point getP1() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.p1;
    }

    @objid ("04470443-0904-4abb-b8c7-5a55c62d117f")
    void setP1(Point value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.p1 = value;
    }

}
