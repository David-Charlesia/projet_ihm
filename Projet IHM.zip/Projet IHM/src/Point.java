import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("ab1d06da-e09b-4258-ae09-f277112e5470")
public class Point {
    @objid ("2bc68e60-687d-496f-bcc4-584d29f34617")
    private int x;

    @objid ("f060480a-23dc-4f12-8a64-33f62d2d479b")
    private int y;

    @objid ("f4c30870-4251-41f7-9413-b672115dae6a")
    int getX() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.x;
    }

    @objid ("e49fb9cd-646e-4c2e-8380-c493922db3e3")
    void setX(int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.x = value;
    }

    @objid ("a4aa8482-1a75-44da-822a-935f07e7c9cf")
    int getY() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.y;
    }

    @objid ("7fa48e3f-8da8-4439-bcee-0c2a03cecc9c")
    void setY(int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.y = value;
    }

}
